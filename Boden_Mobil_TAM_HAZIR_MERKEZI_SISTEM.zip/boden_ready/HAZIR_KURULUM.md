# BODEN MERKEZİ — HAZIR KURULUM PAKETİ

Bu paket, çok kullanıcılı ortak Boden verisi için PostgreSQL kullanan merkezi API ve Android projesini içerir.

## Tek zorunlu dış adım

Bu çalışma ortamı senin adına dış bir bulut hesabı açıp uygulamayı internete yayınlayamaz. Bu nedenle bir kez Render hesabında deploy işlemini başlatmak gerekir.

1. Render'a girin: https://render.com
2. GitHub'a bu klasörü yükleyin.
3. Render → New → Blueprint seçin.
4. GitHub deposunu seçin ve `render.yaml` dosyasını deploy edin.
5. Render, `boden-merkezi-api` ve `boden-db` servislerini oluşturur.
6. Web servisinin verdiği HTTPS adresi `https://...onrender.com` olacaktır.
7. Bu adresi bana gönderin; Android APK'nın bağlantısını o adrese sabitleyip son APK'yı hazırlayabilirim.

## Neden PostgreSQL?

Önceki V20 SQLite kullanıyordu. Bulut ortamında dosya tabanlı SQLite kalıcı ortak veri için uygun değildir. Bu paket PostgreSQL kullanır; böylece tüm telefonlar aynı merkezi veriyi görür.

## Uygulama tarafı

Android uygulamasındaki `assets/config.js` dosyasındaki API adresi deploy edilen HTTPS adresine ayarlanmalıdır.
