# Boden Mobil - Merkezi Veritabanlı Android Projesi

Bu sürüm mevcut Boden uygulamasını Android içinde çalıştırır ve kayıtları merkezi bir REST API ile senkronize eder.

## 1. Merkezi sunucu
`backend/` klasöründeki API'yi internete HTTPS üzerinden yayınlayın.

## 2. API adresi
`app/src/main/assets/config.js` dosyasında `window.BODEN_API_BASE` değerini gerçek API adresi ile değiştirin.

## 3. Android
Projeyi Android Studio ile açıp APK/AAB derleyin.

### Veri davranışı
- Aynı veritabanına bağlanan tüm cihazlar ortak kayıtları görür.
- Ölçü kayıtları ve uygulamanın mevcut localStorage anahtarları merkezi olarak saklanır.
- Sunucuya erişilemiyorsa uygulama yerel verilerle çalışmaya devam eder ve ekranda `YEREL` durumu gösterilir.

> Not: Bu paket çok kullanıcılı ortak veri altyapısını sağlar. Üretim ortamında kullanıcı kimlik doğrulaması ve yetkilendirme ayrıca eklenmelidir.
