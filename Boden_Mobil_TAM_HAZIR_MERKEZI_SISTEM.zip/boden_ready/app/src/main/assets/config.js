// Render deploy edildikten sonra bu adresi gerçek HTTPS API adresiyle değiştirin.
window.BODEN_API_BASE = 'https://YOUR-RENDER-SERVICE.onrender.com/api';
