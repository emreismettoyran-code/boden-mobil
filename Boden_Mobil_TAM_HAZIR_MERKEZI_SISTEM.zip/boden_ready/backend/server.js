import express from 'express';
import cors from 'cors';
import pg from 'pg';

const { Pool } = pg;
const app = express();
const port = process.env.PORT || 10000;
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL ? { rejectUnauthorized: false } : false });

app.use(cors({ origin: true, credentials: false }));
app.use(express.json({ limit: '10mb' }));

async function init(){
  await pool.query(`CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at BIGINT NOT NULL)`);
}

app.get('/health', async (req,res)=>{
  try { await pool.query('SELECT 1'); res.json({ok:true,service:'boden-shared-api',database:'postgres'}); }
  catch(e){ res.status(503).json({ok:false,error:'database_unavailable'}); }
});

app.get('/api/state', async (req,res)=>{
  try {
    const { rows } = await pool.query('SELECT key,value FROM kv ORDER BY key');
    const state={}; rows.forEach(r=>state[r.key]=r.value);
    res.json({state});
  } catch(e){ res.status(500).json({error:'read_failed'}); }
});

app.put('/api/state/:key', async (req,res)=>{
  try {
    const key=decodeURIComponent(req.params.key);
    const value=String(req.body?.value ?? '');
    await pool.query(`INSERT INTO kv(key,value,updated_at) VALUES($1,$2,$3) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value,updated_at=EXCLUDED.updated_at`,[key,value,Date.now()]);
    res.json({ok:true});
  } catch(e){ res.status(500).json({error:'write_failed'}); }
});

app.delete('/api/state/:key', async (req,res)=>{
  try { await pool.query('DELETE FROM kv WHERE key=$1',[decodeURIComponent(req.params.key)]); res.json({ok:true}); }
  catch(e){ res.status(500).json({error:'delete_failed'}); }
});

app.delete('/api/state', async (req,res)=>{
  try { await pool.query('DELETE FROM kv'); res.json({ok:true}); }
  catch(e){ res.status(500).json({error:'clear_failed'}); }
});

init().then(()=>app.listen(port,'0.0.0.0',()=>console.log(`Boden API listening on ${port}`))).catch(e=>{console.error(e);process.exit(1)});
