# Boden Shared API

Bu sunucu, Boden uygulamasının ortak verilerini tek bir SQLite veritabanında tutar.

## Çalıştırma

```bash
npm install
npm start
```

Sunucu varsayılan olarak `http://localhost:8080` üzerinde çalışır.

Android/iPhone uygulamasında `app/src/main/assets/config.js` içindeki:

`window.BODEN_API_BASE`

değerini sunucunun HTTPS adresine `/api` ekleyerek değiştirin.

Örnek:
`https://boden.example.com/api`

İnternet üzerinden ortak kullanım için sunucunun HTTPS ile yayınlanması gerekir.
